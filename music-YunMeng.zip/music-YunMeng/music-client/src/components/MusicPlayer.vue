<template>
    <v-card class="mt-4">
      <audio controls :src="src" style="width:100%"></audio>
    </v-card>
  </template>
  
  <script>
  export default {
    props: { src: String }
  }
  </script>
  