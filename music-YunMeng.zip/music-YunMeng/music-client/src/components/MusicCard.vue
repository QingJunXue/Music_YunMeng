<template>
    <v-card class="hoverable" @click="goDetail">
      <v-img :src="song.cover" height="200"/>
      <v-card-title>{{ song.title }}</v-card-title>
      <v-card-subtitle>{{ song.artist }}</v-card-subtitle>
    </v-card>
  </template>
  
  <script>
  export default {
    props: { song: Object },
    methods: {
      goDetail() {
        this.$router.push(`/songs/${this.song.id}`)
      }
    }
  }
  </script>
  