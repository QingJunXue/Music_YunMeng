<template>
  <v-app>
    <v-app-bar app color="indigo" dark>
      <v-toolbar-title>悦享音乐</v-toolbar-title>
      <v-spacer/>
      <v-btn text to="/">首页</v-btn>
      <v-btn text to="/songs">歌曲</v-btn>
      <v-btn text to="/artists">歌手</v-btn>
      <v-btn text to="/admin">后台管理</v-btn>
    </v-app-bar>
    <v-main>
      <router-view/>
    </v-main>
  </v-app>
</template>
