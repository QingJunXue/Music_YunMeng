import Vue from 'vue'
import Router from 'vue-router'
import HomeView from '@/views/HomeView.vue'
import SongListView from '@/views/SongListView.vue'
import SongDetailView from '@/views/SongDetailView.vue'
import ArtistListView from '@/views/ArtistListView.vue'
import AdminDashboardView from '@/views/AdminDashboardView.vue'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    { path: '/', component: HomeView },
    { path: '/songs', component: SongListView },
    { path: '/songs/:id', component: SongDetailView },
    { path: '/artists', component: ArtistListView },
    { path: '/admin', component: AdminDashboardView }
  ]
})
