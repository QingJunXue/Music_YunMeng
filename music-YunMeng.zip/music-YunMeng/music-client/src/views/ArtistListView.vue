<template>
  <v-container>
    <h2>🎤 歌手</h2>
    <v-row>
      <v-col cols="12" sm="6" md="4" v-for="a in artists" :key="a.id">
        <v-card>
          <v-img :src="a.avatar" height="200"/>
          <v-card-title>{{ a.name }}</v-card-title>
          <v-card-text>{{ a.description }}</v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: 'ArtistListView',
  data() {
    return {
      artists: [
        { id: 1, name: "周杰伦", avatar: "https://picsum.photos/200?8", description: "台湾流行天王" },
        { id: 2, name: "薛之谦", avatar: "https://picsum.photos/200?9", description: "实力歌手" }
      ]
    }
  }
}
</script>
