<template>
  <v-container>
    <v-jumbotron color="deep-purple accent-4" dark>
      <h1 class="display-2">悦享音乐</h1>
      <p class="lead">在线流媒体音乐平台，播放、上传、评论，尽情享受。</p>
    </v-jumbotron>
    <h2 class="mt-4 mb-4">热门歌曲推荐</h2>
    <v-row>
      <v-col cols="12" sm="6" md="4" v-for="s in songs" :key="s.id">
        <MusicCard :song="s"/>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import MusicCard from '@/components/MusicCard.vue'
export default {
  name: 'HomeView',
  components: { MusicCard },
  data() {
    return {
      songs: [
        { id: 1, title: "稻香", artist: "周杰伦", cover: "https://picsum.photos/200?1" },
        { id: 2, title: "青花瓷", artist: "周杰伦", cover: "https://picsum.photos/200?2" },
        { id: 3, title: "演员", artist: "薛之谦", cover: "https://picsum.photos/200?3" }
      ]
    }
  }
}
</script>
