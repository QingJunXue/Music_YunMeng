<template>
  <v-container>
    <h2>后台管理</h2>
    <v-form ref="form" @submit.prevent="submit">
      <v-text-field v-model="form.title" label="歌曲名称" required/>
      <v-text-field v-model="form.artist" label="歌手" required/>
      <v-file-input v-model="form.cover" label="封面图片" accept="image/*" required/>
      <v-file-input v-model="form.audio" label="音频文件" accept="audio/*" required/>
      <v-btn color="success" type="submit">提交上传</v-btn>
    </v-form>
  </v-container>
</template>

<script>
export default {
  name: 'AdminDashboardView',
  data() {
    return {
      form: {
        title: '',
        artist: '',
        cover: null,
        audio: null
      }
    }
  },
  methods: {
    submit() {
      const data = new FormData()
      data.append('title', this.form.title)
      data.append('artist', this.form.artist)
      data.append('cover', this.form.cover)
      data.append('audio', this.form.audio)
      // TODO: axios.post('/api/songs', data)
      alert('表单已提交 ✅（请接入后端）')
    }
  }
}
</script>
