<template>
  <v-container>
    <h2>🎧 歌曲列表</h2>
    <v-row>
      <v-col cols="12" sm="6" md="4" v-for="song in songs" :key="song.id">
        <MusicCard :song="song"/>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import MusicCard from '@/components/MusicCard.vue'
export default {
  name: 'SongListView',
  components: { MusicCard },
  data() {
    return {
      songs: [
        { id: 1, title: "稻香", artist: "周杰伦", cover: "https://picsum.photos/200?4" },
        { id: 2, title: "青花瓷", artist: "周杰伦", cover: "https://picsum.photos/200?5" },
        { id: 3, title: "演员", artist: "薛之谦", cover: "https://picsum.photos/200?6" }
      ]
    }
  }
}
</script>
