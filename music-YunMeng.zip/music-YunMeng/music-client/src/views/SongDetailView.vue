<template>
  <v-container>
    <h2>{{ song.title }} - {{ song.artist }}</h2>
    <v-row>
      <v-col cols="12" md="4">
        <v-img :src="song.cover" height="300"/>
        <MusicPlayer :src="song.audio_url"/>
      </v-col>
      <v-col cols="12" md="8">
        <v-card>
          <v-card-title>歌词</v-card-title>
          <v-card-text style="white-space: pre-line;">
            {{ lyrics }}
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import MusicPlayer from '@/components/MusicPlayer.vue'
export default {
  name: 'SongDetailView',
  components: { MusicPlayer },
  data() {
    return {
      song: {
        id: 1,
        title: "稻香",
        artist: "周杰伦",
        cover: "https://picsum.photos/300?7",
        audio_url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
      },
      lyrics: `
[00:00] 让我再听一次稻香
[00:10] 青春总有遗憾
[00:20] 梦里花落知多少
`.trim()
    }
  }
}
</script>
