module.exports = {
  publicPath: './',
  devServer: {
    historyApiFallback: true
  }
}