// routes/music.js
const express = require('express');
const router = express.Router();
const musicController = require('../controllers/musicController');
const authMiddleware = require('../middleware/auth');
const multer = require('multer');
const path = require('path');

// 上传配置（本地保存）
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/music/');
  },
  filename: (req, file, cb) => {
    // 保持原扩展名
    const ext = path.extname(file.originalname);
    const filename = Date.now() + ext;
    cb(null, filename);
  }
});
const upload = multer({ storage });

// 列表
router.get('/', musicController.getAllMusic);

// 上传（仅admin）
router.post('/upload', authMiddleware.verifyToken, authMiddleware.isAdmin, upload.single('file'), musicController.uploadMusic);

// 删除（仅admin）
router.delete('/:id', authMiddleware.verifyToken, authMiddleware.isAdmin, musicController.deleteMusic);

module.exports = router;
