// controllers/musicController.js
const db = require('../config/db');
const fs = require('fs');
const path = require('path');

exports.getAllMusic = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM music');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: '服务器错误' });
  }
};

exports.uploadMusic = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: '未上传文件' });

    const { originalname, filename, mimetype } = req.file;

    // 存入数据库
    await db.query('INSERT INTO music (title, filename, mimetype) VALUES (?, ?, ?)', [originalname, filename, mimetype]);

    res.json({ message: '上传成功' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: '服务器错误' });
  }
};

exports.deleteMusic = async (req, res) => {
  try {
    const id = req.params.id;
    const [rows] = await db.query('SELECT * FROM music WHERE id = ?', [id]);
    if (rows.length === 0) return res.status(404).json({ message: '歌曲不存在' });

    const filepath = path.join(__dirname, '../uploads/music', rows[0].filename);
    // 删除文件
    fs.unlink(filepath, (err) => {
      if (err) console.warn('文件删除失败:', err);
    });

    await db.query('DELETE FROM music WHERE id = ?', [id]);
    res.json({ message: '删除成功' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: '服务器错误' });
  }
};
