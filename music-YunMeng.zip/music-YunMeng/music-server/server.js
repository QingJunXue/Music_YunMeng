// server.js
const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const musicRoutes = require('./routes/music');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// 静态文件服务（用于访问上传的音乐文件和图片）
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 路由
app.use('/api/auth', authRoutes);
app.use('/api/music', musicRoutes);

// 404 处理
app.use((req, res) => {
  res.status(404).json({ message: '接口不存在' });
});

// 启动服务
app.listen(PORT, () => {
  console.log(`服务器启动，端口：${PORT}。地址:http://localhost:${PORT}`);
});
